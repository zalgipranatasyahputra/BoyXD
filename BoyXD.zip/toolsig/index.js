'use strict'
const Client = require('instagram-private-api').V1;
const delay = require('delay');
const chalk = require('chalk');
const inquirer = require('inquirer');
var moment = require("moment");
var colors = require('colors');
var userHome = require('user-home');

//DETECT IP *START!
var os = require('os');
var interfaces = os.networkInterfaces();
var addresses = [];
for (var k in interfaces) {
    for (var k2 in interfaces[k]) {
        var address = interfaces[k][k2];
        if (address.family === 'IPv4' && !address.internal) {
            addresses.push(address.address);
        }
    }
}
//DETECT IP *END!

const questionTools = [{
    type: "list",
    name: "Tools",
    message: "Pilih alat:\n  Baca (❆ Informasi) terlebih dahulu sebelum menggunakan alat ini!\n\n",
    choices: [
        "❆ Informasi",
        "❆ Bom Like Target",
        "❆ Bot Like Timeline v1",
        "❆ Bot Like Timeline v2",
        "❆ Hapus Massal Posting / Foto",
        "❆ Berhenti Mengikuti Semua",
        "❆ Berhenti Mengikuti Yang Tidak Mengikuti Balik",
        "❆ L-C dengan Target Pengikut",
        "❆ F-L dengan Target Pengikut",
        "❆ F-L-C dengan Target Pengikut",
        "❆ F-L-C dengan Target Media",
        "❆ F-L-C dengan Target Hashtag",
        "❆ F-L-C dengan Target Lokasi",
        "\n"
    ]
}]
const main = async () => {
    try {
        var toolChoise = await inquirer.prompt(questionTools);
        toolChoise = toolChoise.Tools;
        switch (toolChoise) {

            case "❆ Informasi":
                const informationtools = require('./tools/infotools.js');
                await infotools();
                break;

            case "❆ Bom Like Target":
                const bomliketarget = require('./tools/bomliketarget.js');
                await bomliketarget();
                break;

            case "❆ Bot Like Timeline v1":
                console.log("\n ERROR:".red.bold, "Maaf, Untuk Saat Ini Bot Like Timeline v1 ERROR, Gunakan Tools Lain!\n".green.bold, "STATUS: ERROR! Please try again!".yellow.bold);
                break;

            case "❆ Bot Like Timeline v2":
                console.log("\n ERROR:".red.bold, "Maaf, Untuk Saat Ini Bot Like Timeline v2 ERROR, Gunakan Tools Lain!\n".green.bold, "STATUS: ERROR! Please try again!".yellow.bold);
                break;

            case "❆ Hapus Massal Posting / Foto":
                const dellallphoto = require('./tools/dellallphoto.js');
                await dellallphoto();
                break;

            case "❆ Berhenti Mengikuti Semua":
                const unfollall = require('./tools/unfollall.js');
                await unfollall();
                break;

            case "❆ Berhenti Mengikuti Yang Tidak Mengikuti Balik":
                const unfollnotfollback = require('./tools/unfollnotfollback.js');
                await unfollnotfollback();
                break;

            case "❆ L-C dengan Target Pengikut":
                const lnktauto = require('./tools/lnktauto.js');
                await unfollnotfollback();
                break;

            case "❆ F-L dengan Target Pengikut":
                const fnlauto = require('./tools/fnlauto.js');
                await unfollnotfollback();
                break;

            case "❆ F-L-C dengan Target Pengikut":
                const fftauto = require('./tools/fftauto.js');
                await fftauto();
                break;

            case "❆ F-L-C dengan Target Media":
                const flmauto = require('./tools/fmtauto.js');
                await flmauto();
                break;

            case "❆ F-L-C dengan Target Hashtag":
                const fah = require('./tools/fhtauto.js');
                await fah();
                break;

            case "❆ F-L-C dengan Target Lokasi":
                const flaauto = require('./tools/fltauto.js');
                await flaauto();
                break;

            default:
                console.log("\n ERROR:".red.bold, "Aw, Snap! Something went wrong while displaying this tool!\n".green.bold, "NOT FOUND! Please try again!".yellow.bold);
        }
    } catch (e) {}
}

console.log(chalk `{bold.green
  Ξ TITLE  : Instagram Private Tools v2.5
  Ξ UPLOAD : c:/users/zalgipranatasyahputra/BoyXD
  Ξ CODEBY : Zalgi Pranata Syahputra [BoyXD]
  Ξ UPDATE : BoyXD [21/08/2020]
  Ξ FILES  : https://github.com/zalgipranatasyahputra/BoyXD
console.log(chalk `{bold.red   •••••••••••••••••••••••••••••••••••••••••}`);
console.log("  Ξ START  : ".bold.red + moment().format('D MMMM YYYY, h:mm:ss a'));
console.log("  Ξ YPATH  : ".bold.red + userHome);
console.log("  Ξ YOUIP  : ".bold.red + addresses);
console.log(chalk `{bold.red   •••••••••••••••••••••••••••••••••••••••••}`);
console.log(chalk `{bold.yellow
  Ξ THANKS : Instagram Private Tools [Original Source File]
           : WhatsApp:0896-0252-9852 Youtube:BoyXD}`);
console.log('\n')
main();
//by 1dcea8095a18ac73b764c19e40644b5